// robots.txt file/url parser/downloader
// pure go code
// Author: ArkAngeL43 | https://github.com/ArkAngeL43
// in workings with the Red-Rabbit project this will parse the
// robots.txt filepath to a url then if it returns with a status that is or close
// to OK or HTTPOK/STATOK
// package main decleration here
package main

import (
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"os"
	"strings"
)

var (
	flagname = flag.String("url", "", "URL")
)

func ce(err error, msg string, typer string, exit_code int) bool {
	if err != nil {
		if typer == "fmt" {
			fmt.Println(err, msg, exit_code)
			os.Exit(exit_code)
		}
		if typer == "log" {
			log.Fatal(err, msg)
			os.Exit(exit_code)
		}
	} else {
		return true
	}
	return true
}

//https://www.google.com/robots.txt
// make function return boolean based values if the url returns with a status code outside of or statement range
func robot(uri, path string) bool {
	parsed_uri := uri + path
	resp, err := http.Get(parsed_uri)
	ce(err, "ERROR DURING GET REQUEST LINE 32 ", "panic", 1)
	if resp.StatusCode == 100 || resp.StatusCode == 200 || resp.StatusCode == 201 || resp.StatusCode == 202 {
		fmt.Println(resp.Status)
		body, err := ioutil.ReadAll(resp.Body)
		ce(err, "ERROR: the following exception occured when reading the HTTP response body", "log", 1)
		fmt.Println(string(body))
		resp.Body.Close()
		resp, err = http.Head(parsed_uri)
		ce(err, "ERROR: the following exception occured when reading the HTTP HEAD", "log", 1)
		resp.Body.Close()
		fmt.Println(resp.Status)
		form := url.Values{}
		form.Add(parsed_uri, "name1")
		resp, err = http.Post(
			parsed_uri,
			"application/x-www-form-urlencoded",
			strings.NewReader(form.Encode()),
		)
		ce(err, "ERROR: the following exception occured when POSTING the HTTP data", "log", 1)
		resp.Body.Close()
		fmt.Println(resp.Status)
		req, err := http.NewRequest("DELETE", parsed_uri, nil)
		ce(err, "ERROR: the following exception occured when making the new request method DELETE", "log", 1)
		var client http.Client
		resp, err = client.Do(req)
		ce(err, "ERROR: the following exception occured when SENDING the HTTP DELETE method request", "log", 1)
		resp.Body.Close()
		fmt.Println(resp.Status)

		req, err = http.NewRequest("PUT", parsed_uri, strings.NewReader(form.Encode()))
		ce(err, "ERROR: the following exception occured when making the new request method PUT", "log", 1)
		resp, err = client.Do(req)
		ce(err, "ERROR: the following exception occured when executing the HTTP response body", "log", 1)
		resp.Body.Close()
		fmt.Println(resp.Status)
		return true
	} else {
		fmt.Println("ERR: sorry but the http response code i got was not in range => ", resp.StatusCode)
		return false
	}
}

func main() {
	flag.Parse()
	path1 := "/robots.txt"
	robot(*flagname, path1)
}
