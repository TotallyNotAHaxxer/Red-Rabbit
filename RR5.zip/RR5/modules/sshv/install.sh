pip install colorama 
pip install cprint 
pip install termcolor
sudo apt-get install arp-scan 
sudo apt-get install gnome-terminal
sudo apt-get install hydra 
sudo apt-get install nmap 
sudo apt-get install ssh
sudo apt-get install scp 
sudo gem install net-ssh 
sudo gem install colorize 
sudo apt install sshfs
