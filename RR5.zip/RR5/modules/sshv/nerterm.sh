clear
echo 'installing scripts and payloads in root directory '
sleep 1
python3 install-script.py 

