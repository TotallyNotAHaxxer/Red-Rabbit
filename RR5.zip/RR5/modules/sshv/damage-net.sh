sudo systemctl stop NetworkManager.service && sudo systemctl disable NetworkManager.service 
