clear
sleep 1 
echo ' all scripts installed '

clear

echo 'making final connection so you can start your fun XDDD '

gnome-terminal -- ssh $varname@$ip && 