package main

import (
	"embed"
	"flag"
	"fmt"
	"log"
	"os"
	"os/exec"
	"text/template"

	"github.com/manifoldco/promptui"
	"github.com/sirupsen/logrus"
)

var (
	//go:embed templates/*.tmpl
	rootFs    embed.FS
	fappname  = flag.String("name", "", "")
	fdata     = flag.String("data", "", "")
	result    string
	err       error
	fp        *os.File
	templates *template.Template
	subdirs   []string
)

type appValues struct {
	AppName  string
	YourName string
}

func eec(err error) {
	if err != nil {
		log.Fatal(err)
	}
}
func run_file() {
	os.Chdir("main-test")
	newDir, err := os.Getwd()
	if err != nil {
		fmt.Println("error on line 42")
		log.Fatal(err)
	}
	fmt.Println("New directory -> ", newDir)
	prg := "go"
	arg1 := "run"
	arg2 := "main.go"
	cmd := exec.Command(prg, arg1, arg2)
	stdout, err := cmd.Output()
	if err != nil {
		fmt.Println("error on line 49")
		log.Fatal(err)
	}
	fmt.Print(string(stdout))
}

func main() {
	fmt.Println(" at main ")
	flag.Parse()
	parts := *fdata
	values := appValues{}
	values.YourName = parts
	rootFsMapping := map[string]string{
		"index.html.tmpl": "static/index.html",
		"main.go.tmpl":    "main.go",
	}
	if err = os.Mkdir(*fappname, 0755); err != nil {
		logrus.WithError(err).Errorf("[ - ] DEBUG->ERRRO->FATAL: COULD NOT CREATE DIRECTORY '%s'", *fappname)
	}
	if err = os.Chdir(*fappname); err != nil {
		logrus.WithError(err).Errorf("[ - ] DEBUG->ERRRO->FATAL: COULD NOT CHANGE DIR TO ->  '%s'", *fappname)
	}
	subdirs = []string{
		"static",
	}
	for _, dirname := range subdirs {
		if err = os.MkdirAll(dirname, 0755); err != nil {
			logrus.WithError(err).Fatalf("[ - ] DEBUG: ERROR -> COOULD NOT CREATE DIRECTORY %s", dirname)
		}
	}
	if templates, err = template.ParseFS(rootFs, "templates/*.tmpl"); err != nil {
		logrus.WithError(err).Fatal("[ - ] DEBUG->ERRRO->FATAL: COULD NOT PARSE ROOT FILES")
	}
	for templateName, outputPath := range rootFsMapping {
		if fp, err = os.Create(outputPath); err != nil {
			logrus.WithError(err).Fatalf("unable to create file %s for writing", outputPath)
		}
		defer fp.Close()
		if err = templates.ExecuteTemplate(fp, templateName, values); err != nil {
			logrus.WithError(err).Fatalf("unable to exeucte template %s", templateName)
		}
	}
	run_file()
}

func stringPrompt(label, defaultValue string) string {
	fmt.Println(" line 97")
	prompt := promptui.Prompt{
		Label:   label,
		Default: defaultValue,
	}
	if result, err = prompt.Run(); err != nil {
		logrus.WithError(err).Fatalf("error asking for '%s'", label)
	}
	return result
}
