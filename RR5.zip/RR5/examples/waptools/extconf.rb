require 'mkmf'

create_header
create_makefile 'waptools'
